# tryfail

This project is a java application
